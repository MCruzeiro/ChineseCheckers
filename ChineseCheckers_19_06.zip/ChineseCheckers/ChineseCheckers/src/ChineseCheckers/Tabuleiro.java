/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import javafx.concurrent.Task;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Asus
 */
public class Tabuleiro extends Task {

    Circulo[][] tabuleiro;
    static int n = 9;

    AnchorPane a;

    public Tabuleiro(AnchorPane a) {
        this.tabuleiro = new Circulo[n][n];
        this.a = a;
        criaCirculos();

    }

    public void desenhaTabuleiro() {
        System.out.println("Vou desenhar o tabuleiro");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a.getChildren().add(tabuleiro[i][j]);
            }
        }
        System.out.println("Desenhou o tabuleiro");
    }

    @Override
    protected Object call() throws Exception {
        desenhaTabuleiro();
        return null;
    }

    public void setCorJogador1(String cor) {
        tabuleiro[0][0].setCor(cor);
        tabuleiro[0][1].setCor(cor);
        tabuleiro[0][2].setCor(cor);
        tabuleiro[0][3].setCor(cor);
        tabuleiro[0][4].setCor(cor);
        tabuleiro[0][5].setCor(cor);
        tabuleiro[0][6].setCor(cor);
        tabuleiro[0][7].setCor(cor);
        tabuleiro[0][8].setCor(cor);
        tabuleiro[1][0].setCor(cor);

    }

    public void setCorJogador2(String cor) {
        tabuleiro[1][1].setCor(cor);
        tabuleiro[1][2].setCor(cor);
        tabuleiro[1][3].setCor(cor);
        tabuleiro[1][4].setCor(cor);
        tabuleiro[1][5].setCor(cor);
        tabuleiro[1][6].setCor(cor);
        tabuleiro[1][7].setCor(cor);
        tabuleiro[1][8].setCor(cor);
        tabuleiro[2][0].setCor(cor);
        tabuleiro[2][1].setCor(cor);

    }

    public void preparaJogada(String cor) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                //Todos que tiverem a cor são cliclaveis
                if (tabuleiro[i][j].getCor().equals(cor)) {
                    tabuleiro[i][j].setOnMouseClicked(e -> {
                        System.out.println("Clicou");
                    });
                }
            }
        }
    }

    private void criaCirculos() {
        tabuleiro[0][0] = new Circulo(343.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[0][1] = new Circulo(271.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[0][2] = new Circulo(295.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[0][3] = new Circulo(319.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[0][4] = new Circulo(319.0, 407.0, DadosJogo.Vermelho);
        tabuleiro[0][5] = new Circulo(295.0, 407.0, DadosJogo.Vermelho);
        tabuleiro[0][6] = new Circulo(307.0, 432.0, DadosJogo.Vermelho);
        tabuleiro[0][7] = new Circulo(307.0, 385.0, DadosJogo.Vermelho);
        tabuleiro[0][8] = new Circulo(282.0, 386.0, DadosJogo.Vermelho);
        tabuleiro[1][0] = new Circulo(332.0, 386.0, DadosJogo.Vermelho);
        tabuleiro[1][1] = new Circulo(332.0, 91.0, DadosJogo.Verde);
        tabuleiro[1][2] = new Circulo(282.0, 91.0, DadosJogo.Verde);
        tabuleiro[1][3] = new Circulo(307.0, 90.0, DadosJogo.Verde);
        tabuleiro[1][4] = new Circulo(307.0, 42.0, DadosJogo.Verde);
        tabuleiro[1][5] = new Circulo(295.0, 67.0, DadosJogo.Verde);
        tabuleiro[1][6] = new Circulo(319.0, 67.0, DadosJogo.Verde);
        tabuleiro[1][7] = new Circulo(319.0, 114.0, DadosJogo.Verde);
        tabuleiro[1][8] = new Circulo(295.0, 114.0, DadosJogo.Verde);
        tabuleiro[2][0] = new Circulo(271.0, 114.0, DadosJogo.Verde);
        tabuleiro[2][1] = new Circulo(343.0, 114.0, DadosJogo.Verde);
        tabuleiro[2][2] = new Circulo(307.0, 332.0, DadosJogo.Branco);
        tabuleiro[2][3] = new Circulo(283.0, 332.0, DadosJogo.Branco);
        tabuleiro[2][4] = new Circulo(259.0, 332.0, DadosJogo.Branco);
        tabuleiro[2][5] = new Circulo(331.0, 332.0, DadosJogo.Branco);
        tabuleiro[2][6] = new Circulo(355.0, 332.0, DadosJogo.Branco);
        tabuleiro[2][7] = new Circulo(356.0, 143.0, DadosJogo.Branco);
        tabuleiro[2][8] = new Circulo(332.0, 143.0, DadosJogo.Branco);
        tabuleiro[3][0] = new Circulo(260.0, 143.0, DadosJogo.Branco);
        tabuleiro[3][1] = new Circulo(284.0, 143.0, DadosJogo.Branco);
        tabuleiro[3][2] = new Circulo(308.0, 143.0, DadosJogo.Branco);
        tabuleiro[3][3] = new Circulo(344.0, 308.0, DadosJogo.Branco);
        tabuleiro[3][4] = new Circulo(320.0, 308.0, DadosJogo.Branco);
        tabuleiro[3][5] = new Circulo(248.0, 308.0, DadosJogo.Branco);
        tabuleiro[3][6] = new Circulo(272.0, 308.0, DadosJogo.Branco);
        tabuleiro[3][7] = new Circulo(296.0, 308.0, DadosJogo.Branco);
        tabuleiro[3][8] = new Circulo(368.0, 309.0, DadosJogo.Branco);
        tabuleiro[4][0] = new Circulo(367.0, 168.0, DadosJogo.Branco);
        tabuleiro[4][1] = new Circulo(295.0, 167.0, DadosJogo.Branco);
        tabuleiro[4][2] = new Circulo(271.0, 167.0, DadosJogo.Branco);
        tabuleiro[4][3] = new Circulo(247.0, 167.0, DadosJogo.Branco);
        tabuleiro[4][4] = new Circulo(319.0, 167.0, DadosJogo.Branco);
        tabuleiro[4][5] = new Circulo(343.0, 167.0, DadosJogo.Branco);
        tabuleiro[4][6] = new Circulo(356.0, 285.0, DadosJogo.Branco);
        tabuleiro[4][7] = new Circulo(284.0, 284.0, DadosJogo.Branco);
        tabuleiro[4][8] = new Circulo(260.0, 284.0, DadosJogo.Branco);
        tabuleiro[5][0] = new Circulo(236.0, 284.0, DadosJogo.Branco);
        tabuleiro[5][1] = new Circulo(308.0, 284.0, DadosJogo.Branco);
        tabuleiro[5][2] = new Circulo(332.0, 284.0, DadosJogo.Branco);
        tabuleiro[5][3] = new Circulo(381.0, 285.0, DadosJogo.Branco);
        tabuleiro[5][4] = new Circulo(380.0, 194.0, DadosJogo.Branco);
        tabuleiro[5][5] = new Circulo(331.0, 193.0, DadosJogo.Branco);
        tabuleiro[5][6] = new Circulo(307.0, 193.0, DadosJogo.Branco);
        tabuleiro[5][7] = new Circulo(235.0, 193.0, DadosJogo.Branco);
        tabuleiro[5][8] = new Circulo(259.0, 193.0, DadosJogo.Branco);
        tabuleiro[6][0] = new Circulo(283.0, 193.0, DadosJogo.Branco);
        tabuleiro[6][1] = new Circulo(355.0, 194.0, DadosJogo.Branco);
        tabuleiro[6][2] = new Circulo(369.0, 262.0, DadosJogo.Branco);
        tabuleiro[6][3] = new Circulo(320.0, 261.0, DadosJogo.Branco);
        tabuleiro[6][4] = new Circulo(296.0, 261.0, DadosJogo.Branco);
        tabuleiro[6][5] = new Circulo(224.0, 261.0, DadosJogo.Branco);
        tabuleiro[6][6] = new Circulo(248.0, 261.0, DadosJogo.Branco);
        tabuleiro[6][7] = new Circulo(272.0, 261.0, DadosJogo.Branco);
        tabuleiro[6][8] = new Circulo(344.0, 262.0, DadosJogo.Branco);
        tabuleiro[7][0] = new Circulo(394.0, 263.0, DadosJogo.Branco);
        tabuleiro[7][1] = new Circulo(383.0, 240.0, DadosJogo.Branco);
        tabuleiro[7][2] = new Circulo(333.0, 239.0, DadosJogo.Branco);
        tabuleiro[7][3] = new Circulo(261.0, 238.0, DadosJogo.Branco);
        tabuleiro[7][4] = new Circulo(237.0, 238.0, DadosJogo.Branco);
        tabuleiro[7][5] = new Circulo(213.0, 238.0, DadosJogo.Branco);
        tabuleiro[7][6] = new Circulo(285.0, 236.0, DadosJogo.Branco);
        tabuleiro[7][7] = new Circulo(309.0, 238.0, DadosJogo.Branco);
        tabuleiro[7][8] = new Circulo(358.0, 239.0, DadosJogo.Branco);
        tabuleiro[8][0] = new Circulo(407.0, 241.0, DadosJogo.Branco);
        tabuleiro[8][1] = new Circulo(395.0, 217.0, DadosJogo.Branco);
        tabuleiro[8][2] = new Circulo(345.0, 216.0, DadosJogo.Branco);
        tabuleiro[8][3] = new Circulo(273.0, 215.0, DadosJogo.Branco);
        tabuleiro[8][4] = new Circulo(249.0, 215.0, DadosJogo.Branco);
        tabuleiro[8][5] = new Circulo(225.0, 215.0, DadosJogo.Branco);
        tabuleiro[8][6] = new Circulo(297.0, 215.0, DadosJogo.Branco);
        tabuleiro[8][7] = new Circulo(321.0, 215.0, DadosJogo.Branco);
        tabuleiro[8][8] = new Circulo(370.0, 216.0, DadosJogo.Branco);
    }

}
