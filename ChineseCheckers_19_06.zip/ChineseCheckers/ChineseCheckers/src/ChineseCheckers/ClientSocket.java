package ChineseCheckers;

import java.io.*;
import java.net.*;

public class ClientSocket {

    String serverName;
    int serverPort;

    Socket s;
    DataInputStream dis;
    DataOutputStream dos;
    boolean ligado;

    public ClientSocket(String serverName, int serverPort) {
        this.serverName = serverName;
        this.serverPort = serverPort;
        this.s = null;
        this.dis = null;
        this.dos = null;
        this.ligado = false;
    }

    public void enviaMensagem(String mensagem) throws IOException {
        if (ligado) {
            dos.writeUTF(mensagem);
        }
    }

    public String recebeMensagem() throws IOException {
        String mensagem = null;
        if (ligado) {
            mensagem = dis.readUTF();
        }
        return mensagem;
    }

    public void liga() throws IOException {
        if (!ligado) {
            InetAddress ip = InetAddress.getByName(serverName);
            s = new Socket(ip, serverPort);
            dis = new DataInputStream(s.getInputStream());
            dos = new DataOutputStream(s.getOutputStream());
        }
        ligado = true;
    }

    public void desliga() throws IOException {
        if (ligado) {
            s.close();
            dis = null;
            dos = null;
        }
        ligado = false;
    }
}
