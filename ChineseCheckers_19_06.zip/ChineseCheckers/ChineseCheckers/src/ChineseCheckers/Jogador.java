package ChineseCheckers;

import java.util.Random;

public class Jogador {

    public static String cor1 = "#ff1f1f";
    public static String cor2 = "#ffc91f";
    public static String cor3 = "#009427";
    public static String cor4 = "#eeff00";
    String cor, nome;
    boolean turno;
    int sorteio;

    public Jogador(String cor, String nome, boolean turno) {
        this.cor = cor;
        this.nome = nome;
        this.turno = turno;
    }

    public int sortear() {
        //Atirar um dado ao ar para ver quem joga primeiro
        Random sortear = new Random();
        sorteio = sortear.nextInt(5) + 1;

        return sorteio;

    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isTurno() {
        return turno;
    }

    public void setTurno(boolean turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Jogador{" + "cor=" + cor + ", nome=" + nome + ", turno=" + turno + '}';
    }

}
