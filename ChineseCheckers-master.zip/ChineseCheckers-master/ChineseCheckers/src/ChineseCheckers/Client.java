
package ChineseCheckers;

import java.io.*;
import java.net.*;
import java.util.*;

public class Client implements Runnable {

    final static int ServerPort = 1234;
    final static String ServerName = "localhost";
    Socket s;
    DataInputStream dis;
    DataOutputStream dos;

    public Client() throws UnknownHostException, IOException {
        InetAddress ip = InetAddress.getByName(ServerName);
        s = new Socket(ip, ServerPort);
        dis = new DataInputStream(s.getInputStream());
        dos = new DataOutputStream(s.getOutputStream());
    }

    public void enviaMensagem(String mensagem) throws IOException {
        dos.writeUTF(mensagem);
    }

    @Override
    public void run() {
        while (true) {
            try {
                String msg = dis.readUTF();
                System.out.println(msg);
            } catch (IOException e) {
            }
        }
    }
}
