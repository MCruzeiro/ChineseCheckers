package ChineseCheckers;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ClientSocket implements Runnable {

    final static int ServerPort = 1234;
    final static String ServerName = "localhost";
    Socket s;
    InetAddress ip;
    DataInputStream dis;
    DataOutputStream dos;
    boolean ligado;
    Stage stage;

    public ClientSocket() throws IOException {
        ip = InetAddress.getByName(ServerName);
        s = null;
        dis = null;
        dos = null;
        ligado = false;
        stage = null;
    }

    //Synchronized ?
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void enviaMensagem(String mensagem) throws IOException {
        if (ligado) {
            dos.writeUTF(mensagem);
        }
    }

    public void liga() throws IOException {
        if (!ligado) {
            s = new Socket(ip, ServerPort);
            dis = new DataInputStream(s.getInputStream());
            dos = new DataOutputStream(s.getOutputStream());
        }

        ligado = true;

    }

    public void desliga() throws IOException {
        if (ligado) {
            s.close();
            dis = null;
            dos = null;
        }
        ligado = false;

    }

    public void enviaJogador(DadosJogo dj) throws IOException {
        if (ligado) {
            String msg = "Jogador#" + dj.jogador1.nome + "#" + dj.jogador1.cor;
            //Enviar Mensagem com os nossos dados: Jogador#NomeJogador#Cor
            dos.writeUTF(msg);
        }
    }

    private void RespondeJogo() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        FXMLDocumentController c = loader.getController();
        // c.setDadosJogo(dj);

        //Stage window = (Stage) Sair.getScene().getWindow();
        stage.setScene(new Scene(root));

    }

    @Override
    public void run() {
        while (ligado) {
            try {
                String msg = dis.readUTF();
                System.out.println(msg);

                //Receber Mensagem com dados do adversario: Jogador#NomeJogador#Cor
                StringTokenizer st = new StringTokenizer(msg, "#");
                String item1 = st.nextToken();
                if (item1.equals("Jogador")) {
                    String item2 = st.nextToken();
                    String item3 = st.nextToken();
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                RespondeJogo();
                            } catch (IOException ex) {

                            }
                        }
                    });

                }
                System.out.println(msg);
            } catch (IOException e) {
                ligado = false;
            }
        }
    }
}
