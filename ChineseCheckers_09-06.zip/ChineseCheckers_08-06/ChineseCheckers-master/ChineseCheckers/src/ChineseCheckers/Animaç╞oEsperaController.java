/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.ResourceBundle;
import javafx.animation.FillTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author João Miranda
 */
public class AnimaçãoEsperaController implements Initializable {

    @FXML
    private Circle Circle2;
    @FXML
    private Circle Circle1;
    @FXML
    private Circle Circle3;
    @FXML
    private Button Sair;
    private DadosJogo dj;

    public void setDadosJogo(DadosJogo dj) throws IOException {
        this.dj = dj;
        dj.cs.liga();
        dj.cs.enviaJogador(dj);
        dj.cs.recebeJogador(dj);

    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        TranslateTransition translateTransition = new TranslateTransition();
        translateTransition.setDuration(javafx.util.Duration.millis(1000));
        translateTransition.setNode(Circle1);
        translateTransition.setByY(50);
        translateTransition.setCycleCount(100000);
        translateTransition.setAutoReverse(true);
        translateTransition.play();

        TranslateTransition translateTransition2 = new TranslateTransition();
        translateTransition2.setDuration(javafx.util.Duration.millis(1000));
        translateTransition2.setNode(Circle3);
        translateTransition2.setByY(50);
        translateTransition2.setCycleCount(100000);
        translateTransition2.setAutoReverse(true);
        translateTransition2.play();

        TranslateTransition translateTransition3 = new TranslateTransition();
        translateTransition3.setDuration(javafx.util.Duration.millis(1000));
        translateTransition3.setNode(Circle2);
        translateTransition3.setByY(50);
        translateTransition3.setCycleCount(100000);
        translateTransition3.setAutoReverse(true);
        translateTransition3.play();
    }

    @FXML
    private void RespondeSair(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root = loader.load();
        MenuController mc = loader.getController();
        mc.setDadosJogo(dj);

        Stage window = (Stage) Sair.getScene().getWindow();
        window.setScene(new Scene(root));

    }

}
