package ChineseCheckers;

import java.io.*;
import java.net.*;
import java.util.*;

public class ClientSocket implements Runnable {

    final static int ServerPort = 1234;
    final static String ServerName = "localhost";
    Socket s;
    InetAddress ip;
    DataInputStream dis;
    DataOutputStream dos;
    boolean ligado;

    public ClientSocket() throws IOException {
        ip = InetAddress.getByName(ServerName);
        s = null;
        dis = null;
        dos = null;
        ligado = false;
    }

    public void enviaMensagem(String mensagem) throws IOException {
        dos.writeUTF(mensagem);
    }

    public void liga() throws IOException {
        if (!ligado) {
            s = new Socket(ip, ServerPort);
            dis = new DataInputStream(s.getInputStream());
            dos = new DataOutputStream(s.getOutputStream());
        }

        ligado = true;

    }

    public void desliga() throws IOException {
        if (ligado) {
            s.close();
            dis = null;
            dos = null;
        }
        ligado = false;

    }

    public void recebeJogador(DadosJogo dj) throws IOException {
        if (ligado) {
            String msg = dis.readUTF();
            //Receber Mensagem com dados do adversario: Jogador#NomeJogador#Cor
            StringTokenizer st = new StringTokenizer(msg, "#");
            String item1 = st.nextToken();
            if (item1.equals("Jogador")) {
                String item2 = st.nextToken();
                String item3 = st.nextToken();
                dj.jogador2.nome = item2;
                dj.jogador2.cor = item3;
            }
            System.out.println(msg);
        }

    }

    public void enviaJogador(DadosJogo dj) throws IOException {
        if (ligado) {
            String msg = "Jogador#" + dj.jogador1.nome + "#" + dj.jogador1.cor;
            //Enviar Mensagem com os nossos dados: Jogador#NomeJogador#Cor
            dos.writeUTF(msg);
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                String msg = dis.readUTF();
                System.out.println(msg);
            } catch (IOException e) {
            }
        }
    }
}
