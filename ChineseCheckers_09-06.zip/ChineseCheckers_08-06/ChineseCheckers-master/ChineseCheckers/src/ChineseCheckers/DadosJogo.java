package ChineseCheckers;

import java.io.IOException;

public class DadosJogo {

    Jogador jogador1, jogador2;
    ClientSocket cs;
    public static String Vermelho = "#ff1f1f";
    public static String Laranja = "#ffc91f";
    public static String Amarelo = "#009427";
    public static String Verde = "#eeff00";

    DadosJogo() throws IOException {
        this.jogador1 = new Jogador(Vermelho, "Jogador1", true);
        this.jogador2 = new Jogador(Laranja, "Jogador2", false);
        this.cs = new ClientSocket();
        
        

    }

    public Jogador getJogador1() {
        return jogador1;
    }

    public void setJogador1(Jogador jogador1) {
        this.jogador1 = jogador1;
    }

    public Jogador getJogador2() {
        return jogador2;
    }

    public void setJogador2(Jogador jogador2) {
        this.jogador2 = jogador2;
    }

    public ClientSocket getCs() {
        return cs;
    }

    public void setCs(ClientSocket cs) {
        this.cs = cs;
    }
    
    

}
