/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;
//package MenuImicial;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author João Miranda
 */
public class ChineseCheckers extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        //Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        scene.getStylesheets().add(ChineseCheckers.class.getResource("style.css").toExternalForm());
        stage.show();
        
        Client c = new Client();
        Thread t = new Thread(c);
        c.enviaMensagem("Inicio de Jogo");
        System.err.println("Enviou mensagem");
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
