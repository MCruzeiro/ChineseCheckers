/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuInicial;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author João Miranda
 */
public class DefinirJogadorController implements Initializable {

    @FXML
    private CheckBox CheckboxVermelho;
    @FXML
    private CheckBox CheckboxLaranja;
    @FXML
    private CheckBox CheckboxAmarelo;
    @FXML
    private CheckBox CheckboxVerde;
    @FXML
    private Button BotaoComecar;
    @FXML
    private Button BotaoRetroceder;
    @FXML
    private TextField labelNome;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void BotaoRetroceder() throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("MenuInicial.fxml"));

        Stage window = (Stage) BotaoRetroceder.getScene().getWindow();
        window.setScene(new Scene(root));
    }

    public void BotaoComecar() throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("AnimaçãoEspera.fxml"));

        Stage window = (Stage) BotaoComecar.getScene().getWindow();
        window.setScene(new Scene(root));
    }

}
