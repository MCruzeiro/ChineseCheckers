/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 *
 * @author Asus
 */
public class Server {

    static Vector<ClientHandler> jogadores = new Vector<>();
    static int i = 0;
    final static int ServerPort = 1234;

    public static void main(String[] args) throws IOException {
        System.out.println("Servidor aceita conexões.");
        ServerSocket ss = new ServerSocket(ServerPort);

        Socket s;
        while (true) {
            s = ss.accept();
            System.out.println("Novo client recebido : " + s);

            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            ClientHandler mtch = new ClientHandler(s, "client " + i, dis, dos);
            Thread t = new Thread(mtch);

            System.out.println("Adiciona cliente " + i + " à lista ativa.");
            jogadores.add(mtch);
            t.start();

            i++;
        }
    }

    private static class ClientHandler implements Runnable {

        private String name;
        final DataInputStream dis;
        final DataOutputStream dos;
        Socket s;
        boolean ligado;

        private ClientHandler(Socket s, String name,
                DataInputStream dis, DataOutputStream dos) {
            this.s = s;
            this.dis = dis;
            this.dos = dos;
            this.name = name;
            this.ligado = true;
        }

        @Override
        public void run() {
            String recebido;

            while (ligado) {
                try {
                    recebido = dis.readUTF();
                    System.out.println(recebido);
                    if (recebido.startsWith("logout")) {
                        System.out.println(name + " fez logout");
                        this.ligado = false;
                        this.s.close();
                        break; // while
                    }
                } catch (IOException e) {
                    System.out.println(name + " Erro de leitura: " + e.getMessage());
                    this.ligado = false;
                    break;
                }

                for (ClientHandler ch : Server.jogadores) {
                    if (ch.s.equals(s)) {
                        continue;       //Não enviar a mensagem para ele proprio 
                    }

                    if (ch.ligado) {
                        try {
                            ch.dos.writeUTF(recebido);
                        } catch (IOException ex) {
                            System.out.println("Erro de escrita: " + ex.getMessage());
                        }
                    }
                }

            }

        }
    }
}
