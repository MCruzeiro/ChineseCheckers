/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author João Miranda
 */
public class AnimaçãoEsperaController implements Initializable {

    @FXML
    private Circle Circle2;
    @FXML
    private Circle Circle1;
    @FXML
    private Circle Circle3;
    @FXML
    private Button Sair;

    private DadosJogo dj;
    private RecebeMensagens recebe;
    private Thread th;

    public void setDadosJogo(DadosJogo dj) throws IOException {
        this.dj = dj;
        //liga o socket e cria uma Task para receber mensagem
        dj.cs.liga();
        dj.cs.enviaMensagem("jogador:" + dj.jogador1.nome + ":" + dj.jogador1.cor);
        recebe = new RecebeMensagens(dj.cs);
        recebe.messageProperty().addListener((obs, oldMsg, newMsg) -> {
            StringTokenizer st = new StringTokenizer(newMsg, ":");
            String token = st.nextToken();
            System.out.println("xxxxx");
            if (token.equals("jogador")) {
                System.out.println("Comando jogador");
                dj.jogador2.nome = st.nextToken();
                dj.jogador2.cor = st.nextToken();

                try {
                    dj.cs.enviaMensagem("jogador:" + dj.jogador1.nome + ":" + dj.jogador1.cor);
                    IniciaJogo();
                } catch (IOException ex) {
                    System.out.println("Erro no envio da mensagem.");
                }

            }

        });
        th = new Thread(recebe);
        th.start();
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        TranslateTransition translateTransition = new TranslateTransition();
        translateTransition.setDuration(javafx.util.Duration.millis(1000));
        translateTransition.setNode(Circle1);
        translateTransition.setByY(50);
        translateTransition.setCycleCount(100000);
        translateTransition.setAutoReverse(true);
        translateTransition.play();

        TranslateTransition translateTransition2 = new TranslateTransition();
        translateTransition2.setDuration(javafx.util.Duration.millis(1000));
        translateTransition2.setNode(Circle3);
        translateTransition2.setByY(50);
        translateTransition2.setCycleCount(100000);
        translateTransition2.setAutoReverse(true);
        translateTransition2.play();

        TranslateTransition translateTransition3 = new TranslateTransition();
        translateTransition3.setDuration(javafx.util.Duration.millis(1000));
        translateTransition3.setNode(Circle2);
        translateTransition3.setByY(50);
        translateTransition3.setCycleCount(100000);
        translateTransition3.setAutoReverse(true);
        translateTransition3.play();
    }

    @FXML
    private void RespondeSair(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root = loader.load();
        MenuController mc = loader.getController();

        // cancela a tarefa dereceber e desliga o socket
        recebe.cancel();
        dj.cs.enviaMensagem("logout");
        dj.cs.desliga();
        mc.setDadosJogo(dj);

        Stage window = (Stage) Sair.getScene().getWindow();
        window.setScene(new Scene(root));
    }

    private void IniciaJogo() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        FXMLDocumentController c = loader.getController();
        c.setDadosJogo(dj);
        recebe.cancel(true);
        Stage window = (Stage) Sair.getScene().getWindow(); //Não há botão
        window.setScene(new Scene(root));
    }

}
