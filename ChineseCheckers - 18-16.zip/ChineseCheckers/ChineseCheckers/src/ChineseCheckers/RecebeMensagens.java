package ChineseCheckers;

import javafx.concurrent.Task;

public class RecebeMensagens extends Task {

    private ClientSocket cs;

    public RecebeMensagens(ClientSocket cs) {
        this.cs = cs;
    }

    @Override
    protected String call() throws Exception {
        System.out.println("Recebe Mensagens: ");
        // enquanto o socket estiver lgado e a Task não for cancelaa
        while (cs.ligado && !isCancelled()) {
            // recebe uma mensagem e notifica 
            String mensagem = cs.recebeMensagem();
            updateMessage(mensagem);
            System.out.println("Mensagem recebida: " + mensagem);
        }
        System.out.println("Termina receção de mensagens");

        return null;
    }

}
