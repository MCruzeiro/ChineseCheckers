/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;

/**
 *
 * @author João Miranda
 */
public class FXMLDocumentController implements Initializable {

    private Label label;
    @FXML
    private Polygon Centro;
    @FXML
    private AnchorPane APane;

    @FXML
    private TextArea textAreaMensagem;
    private DadosJogo dj;
    private RecebeMensagens recebe;
    private Thread th;
    @FXML
    private Label jogador1;
    @FXML
    private Label jogador2;
    @FXML
    private Circle bola1;
    @FXML
    private Circle bola2;
    @FXML
    private Button BotaoDesistir;

    public void setDadosJogo(DadosJogo dj) throws IOException {
        desenhaBola();
        this.dj = dj;
        jogador1.setText(dj.jogador1.nome);
        jogador1.setStyle("-fx-alignment: CENTER;  -fx-background-color: " + dj.jogador1.cor + ";");
        jogador2.setText(dj.jogador2.nome);
        jogador2.setStyle("-fx-alignment: CENTER;  -fx-background-color: " + dj.jogador2.cor + ";");
        dj.cs.enviaMensagem("inicio:" + dj.jogador1.nome + ":" + dj.jogador1.cor);
        recebe = new RecebeMensagens(dj.cs);
        recebe.messageProperty().addListener((obs, oldMsg, newMsg) -> {
            textAreaMensagem.setText("Olá");
            System.out.println("Comando inicio" + newMsg);
            StringTokenizer st = new StringTokenizer(newMsg, ":");
            String token = st.nextToken();
            if (token.equals("inicio")) {
                System.out.println("Comando jogador");
                dj.jogador2.nome = st.nextToken();
                dj.jogador2.cor = st.nextToken();

            }

        });
        th = new Thread(recebe);
        th.start();

    }

    public void desenhaBola() {
        //     <Circle fill="DODGERBLUE" layoutX="343.0" layoutY="364.0" radius="11.0" stroke="BLACK" strokeType="INSIDE" />

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }

    @FXML
    private void respondeDesistir(ActionEvent event) throws IOException {         //AMBOS OS JOGADORES TÊM DE SAIR (SÓ ESTÁ A SAIR UM)          
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root = loader.load();
        MenuController mc = loader.getController();

        // cancela a tarefa dereceber e desliga o socket
        recebe.cancel();
        dj.cs.enviaMensagem("logout");
        dj.cs.desliga();
        mc.setDadosJogo(dj);

        Stage window = (Stage) BotaoDesistir.getScene().getWindow();
        window.setScene(new Scene(root));

    }

}
