/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.concurrent.Task;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;

/**
 * <p>
 * Tabuleiro<p>
 * A classe Tabuleiro define o tabuleiro do jogo, utiliza os dados do jogo e e
 * um array duplo de circulos.
 *
 * @author João Miranda & Leonardo Andrade & Miguel Cruzeiro
 */
public class Tabuleiro {

    DadosJogo dj;
    Circulo[][] tabuleiro;
    static int n = 9;

    /**
     * Construtor da classe
     *
     * @param dj
     */
    public Tabuleiro(DadosJogo dj) {
        this.dj = dj;
        this.tabuleiro = new Circulo[n][n];
        criaCirculos();
    }

    /**
     * Neste método são utilizados dois ciclos for para adicionar as bolas no
     * "anchorpane" do tabuleiro e para que cada uma delas tenha propriedades de
     * click
     *
     * @param a
     */
    public void desenhaTabuleiro(AnchorPane a) {
        System.out.println("Vou desenhar o tabuleiro");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a.getChildren().add(tabuleiro[i][j]);
                tabuleiro[i][j].setOnMouseClicked(new CirculoHandler(this, i, j));
            }
        }
        System.out.println("Desenhou o tabuleiro");
    }

    /**
     * Método utilizado para pintar as casas livres com a cor Azul claro e a
     * bola no qual se clicou com Azul Escuro. Ou seja, este método fornece ao
     * jogador informações visuais para onde jogar.
     *
     * @param i
     * @param j
     * @param jogador
     */
    public void jogadorPreparaJogada(int i, int j, Jogador jogador) {
        jogador.jogadaPreparada = true;
        jogador.jogadaI = i;
        jogador.jogadaJ = j;
        marca(i, j, jogador.cor, DadosJogo.AzulEscuro);
        if (livre(i + 1, j)) {
            marca(i + 1, j, DadosJogo.Branco, DadosJogo.AzulClaro);
        } else {
            marca(i + 2, j, DadosJogo.Branco, DadosJogo.AzulClaro); //Passa por cima de uma casa ocupada
        }
        if (livre(i, j + 1)) {
            marca(i, j + 1, DadosJogo.Branco, DadosJogo.AzulClaro);
        } else {
            marca(i, j + 2, DadosJogo.Branco, DadosJogo.AzulClaro);
        }
        if (livre(i + 1, j - 1)) {
            marca(i + 1, j - 1, DadosJogo.Branco, DadosJogo.AzulClaro);
        } else {
            marca(i + 2, j - 2, DadosJogo.Branco, DadosJogo.AzulClaro);
        }
        if (livre(i - 1, j + 1)) {
            marca(i - 1, j + 1, DadosJogo.Branco, DadosJogo.AzulClaro);
        } else {
            marca(i - 2, j + 2, DadosJogo.Branco, DadosJogo.AzulClaro);
        }
        if (livre(i, j - 1)) {
            marca(i, j - 1, DadosJogo.Branco, DadosJogo.AzulClaro);
        } else {
            marca(i, j - 2, DadosJogo.Branco, DadosJogo.AzulClaro);
        }
        if (livre(i - 1, j)) {
            marca(i - 1, j, DadosJogo.Branco, DadosJogo.AzulClaro);
        } else {
            marca(i - 2, j, DadosJogo.Branco, DadosJogo.AzulClaro);
        }

        System.out.println(jogador.nome + " preparou jogada (" + i + "," + j + ")");

    }

    /**
     * Método utilizado para anular uma jogada, faz com que as casas
     * anteriormente pintadas a azul no jogadorPreparaJogada() voltem á cor
     * inicial
     *
     * @param i
     * @param j
     * @param jogador
     */
    public void jogadorAnulaJogada(int i, int j, Jogador jogador) {
        jogador.jogadaPreparada = false;
        marca(i, j, DadosJogo.AzulEscuro, jogador.cor);
        marca(i + 1, j, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i + 2, j, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i, j + 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i, j + 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i + 1, j - 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i + 2, j - 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i - 1, j + 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i - 2, j + 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i, j - 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i, j - 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i - 1, j, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(i - 2, j, DadosJogo.AzulClaro, DadosJogo.Branco);

        System.out.println(jogador.nome + " anulou jogada (" + i + "," + j + ")");

    }

    /**
     * Método utilizado quando uma jogada é concluida, ou seja, move a bola que
     * foi anteriormente selecionada e coloca as restantes na cor inicial
     *
     * @param i
     * @param j
     * @param jogador
     */
    public void jogadorFazJogada(int i, int j, Jogador jogador) {
        System.out.println(jogador);
        jogador.jogadaPreparada = false;
        marca(i, j, DadosJogo.AzulClaro, jogador.cor);
        marca(jogador.jogadaI, jogador.jogadaJ, DadosJogo.AzulEscuro, DadosJogo.Branco);
        marca(jogador.jogadaI + 1, jogador.jogadaJ, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI + 2, jogador.jogadaJ, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI, jogador.jogadaJ + 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI, jogador.jogadaJ + 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI + 1, jogador.jogadaJ - 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI + 2, jogador.jogadaJ - 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI - 1, jogador.jogadaJ + 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI - 2, jogador.jogadaJ + 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI, jogador.jogadaJ - 1, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI, jogador.jogadaJ - 2, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI - 1, jogador.jogadaJ, DadosJogo.AzulClaro, DadosJogo.Branco);
        marca(jogador.jogadaI - 2, jogador.jogadaJ, DadosJogo.AzulClaro, DadosJogo.Branco);

        System.out.println(jogador.nome + " fez jogada (" + i + "," + j + ")");
    }

    /**
     * Método evocado após um click numa bola
     *
     * @param i
     * @param j
     */
    public void jogadorClicou(int i, int j) {
        System.out.println("Clicou no " + i + " " + j);
        // se nao for o turno do jogador sai
        if (dj.jogador1.turno == false) {
            System.out.println("não é a vez de jogar");
            return;
        }
        // ver se clicou numa casa branca
        if (tabuleiro[i][j].getCor().equals(DadosJogo.Branco)) {
            System.out.println("clicou numa casa branca");
            return;
        }
        // ver se clicou numa casa do adversario
        if (tabuleiro[i][j].getCor().equals(dj.jogador2.cor)) {
            System.out.println("clicou numa casa do adversario");
            return;
        }

        // ver se esta com jogada preparada e casa preparada
        if (dj.jogador1.jogadaPreparada && tabuleiro[i][j].getCor().equals(DadosJogo.AzulClaro)) {
            try {
                jogadorFazJogada(i, j, dj.jogador1);
                dj.cs.enviaMensagem("fazJogada:" + i + ":" + j + ":" + dj.jogador1.estado());

                //Verificar se passou por cima de uma peça
                if (Math.abs(dj.jogador1.jogadaI - i) > 1 || Math.abs(dj.jogador1.jogadaJ - j) > 1) {
                    dj.jogador1.jogadaPreparada = false;
                    dj.jogador1.salto = true;
                    dj.jogador1.jogadaI = i;
                    dj.jogador1.jogadaJ = j;
                } else {
                    dj.cs.enviaMensagem("passaVez");
                    dj.jogador1.turno = false;
                    dj.jogador2.turno = true;
                    dj.jogador1.salto = false;
                }
            } catch (IOException ex) {
                System.out.println("Não foi possivel enviar a mensagem");
            }

            return;
        }

        // ver se esta jogada preparada e anula a jogada
        if (dj.jogador1.jogadaPreparada && tabuleiro[i][j].getCor().equals(DadosJogo.AzulEscuro)) {
            try {
                jogadorAnulaJogada(i, j, dj.jogador1);
                dj.cs.enviaMensagem("anulaJogada:" + i + ":" + j + ":" + dj.jogador1.estado());
            } catch (IOException ex) {
                System.out.println("Não foi possivel enviar a mensagem");
            }

            return;
            // acabou a jogada? passa a vez?
        }

        // inicia uma nova jogada se for uma peça sua
        if (tabuleiro[i][j].getCor().equals(dj.jogador1.cor) && podeJogar(i, j)) {
            if (dj.jogador1.salto && (i != dj.jogador1.jogadaI || j != dj.jogador1.jogadaJ)) {
                System.out.println("Não pode jogar, porque só pode jogar na peça anterior");
                return;
            }
            try {
                jogadorPreparaJogada(i, j, dj.jogador1);
                dj.cs.enviaMensagem("preparaJogada:" + i + ":" + j + ":" + dj.jogador1.estado());
            } catch (IOException ex) {
                System.out.println("Não foi possivel enviar a mensagem");
            }
            return;
        }

    }

    // marca uma casa do jogo com uma cor
    /**
     * Método utilizado para marcar uma casa do tabuleiro com uma cor
     *
     * @param i
     * @param j
     * @param corAntiga
     * @param corNova
     */
    public void marca(int i, int j, String corAntiga, String corNova) {
        if (i < 0 || i > 8) {
            return;
        }
        if (j < 0 || j > 8) {
            return;
        }

        if (tabuleiro[i][j].getCor().equals(corAntiga)) {
            tabuleiro[i][j].setCor(corNova);
        }
    }

    // ver se pode jogar - casa livre à volta
    /**
     * Método utilizado para indicar as bolas onde é possivel realizar uma
     * jogada
     *
     * @param i
     * @param j
     * @return
     */
    public boolean podeJogar(int i, int j) {
        return livre(i + 1, j) || livre(i, j + 1)
                || livre(i + 1, j - 1) || livre(i - 1, j + 1)
                || livre(i, j - 1) || livre(i - 1, j - 1);
    }

    // ver se uma casa está livre...
    /**
     * Método utilizado para verificar se uma casa se encontra livre
     *
     * @param i
     * @param j
     * @return
     */
    public boolean livre(int i, int j) {
        if (i < 0 || i > 8) {
            return false;
        }
        if (j < 0 || j > 8) {
            return false;
        }//uma casa livre é branca
        if (tabuleiro[i][j].getCor().equals(DadosJogo.Branco)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Método utilizado para verificar se o jogador venceu o jogo. Valida se as
     * cores das casas iniciais do adversário contém a cor do jogador
     *
     * @param cor
     * @return
     */
    public boolean jogadorVencedor(String cor) {
        // triangulo do jogador todo da mesma cor

        return tabuleiro[8][8].getCor().equals(cor)
                && tabuleiro[8][7].getCor().equals(cor)
                && tabuleiro[7][8].getCor().equals(cor)
                && tabuleiro[8][6].getCor().equals(cor)
                && tabuleiro[7][7].getCor().equals(cor)
                && tabuleiro[6][8].getCor().equals(cor)
                && tabuleiro[8][5].getCor().equals(cor)
                && tabuleiro[7][6].getCor().equals(cor)
                && tabuleiro[6][7].getCor().equals(cor)
                && tabuleiro[5][8].getCor().equals(cor);
    }

    /**
     * Método utilizado para verificar se o adversário venceu o jogo. Valida se
     * as cores das casas iniciais contém a cor do adversário
     *
     * @param cor
     * @return
     */
    public boolean adversarioVencedor(String cor) {
        // triangulo do jogador todo da mesma cor
        return tabuleiro[0][0].getCor().equals(cor)
                && tabuleiro[1][0].getCor().equals(cor)
                && tabuleiro[0][1].getCor().equals(cor)
                && tabuleiro[2][0].getCor().equals(cor)
                && tabuleiro[1][1].getCor().equals(cor)
                && tabuleiro[0][2].getCor().equals(cor)
                && tabuleiro[3][0].getCor().equals(cor)
                && tabuleiro[2][1].getCor().equals(cor)
                && tabuleiro[1][2].getCor().equals(cor)
                && tabuleiro[0][3].getCor().equals(cor);

    }

    /**
     * Método que pinta a cor das casas do jogador com a sua cor
     *
     * @param cor
     */
    public void setCorJogador(String cor) {
        tabuleiro[0][0].setCor(cor);
        tabuleiro[1][0].setCor(cor);
        tabuleiro[0][1].setCor(cor);
        tabuleiro[2][0].setCor(cor);
        tabuleiro[1][1].setCor(cor);
        tabuleiro[0][2].setCor(cor);
        tabuleiro[3][0].setCor(cor);
        tabuleiro[2][1].setCor(cor);
        tabuleiro[1][2].setCor(cor);
        tabuleiro[0][3].setCor(cor);
    }

    /**
     * Método que pinta a cor das casas do adiversário com a sua cor
     *
     * @param cor
     */
    public void setCorAdversario(String cor) {
        tabuleiro[8][8].setCor(cor);
        tabuleiro[8][7].setCor(cor);
        tabuleiro[7][8].setCor(cor);
        tabuleiro[8][6].setCor(cor);
        tabuleiro[7][7].setCor(cor);
        tabuleiro[6][8].setCor(cor);
        tabuleiro[8][5].setCor(cor);
        tabuleiro[7][6].setCor(cor);
        tabuleiro[6][7].setCor(cor);
        tabuleiro[5][8].setCor(cor);
    }

    /**
     * Método que adiciona circulos ao tabuleiro
     */
    private void criaCirculos() {
        // triangulo do jogador (jogador 1)
        tabuleiro[0][0] = new Circulo(307.0, 432.0, DadosJogo.Vermelho);
        tabuleiro[1][0] = new Circulo(295.0, 407.0, DadosJogo.Vermelho);
        tabuleiro[0][1] = new Circulo(319.0, 407.0, DadosJogo.Vermelho);
        tabuleiro[2][0] = new Circulo(282.0, 386.0, DadosJogo.Vermelho);
        tabuleiro[1][1] = new Circulo(307.0, 385.0, DadosJogo.Vermelho);
        tabuleiro[0][2] = new Circulo(332.0, 386.0, DadosJogo.Vermelho);
        tabuleiro[3][0] = new Circulo(271.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[2][1] = new Circulo(295.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[1][2] = new Circulo(319.0, 364.0, DadosJogo.Vermelho);
        tabuleiro[0][3] = new Circulo(343.0, 364.0, DadosJogo.Vermelho);
        // triangulo do adversário (jogador 2)
        tabuleiro[8][8] = new Circulo(307.0, 42.0, DadosJogo.Verde);
        tabuleiro[8][7] = new Circulo(295.0, 67.0, DadosJogo.Verde);
        tabuleiro[7][8] = new Circulo(319.0, 67.0, DadosJogo.Verde);
        tabuleiro[8][6] = new Circulo(282.0, 91.0, DadosJogo.Verde);
        tabuleiro[7][7] = new Circulo(307.0, 90.0, DadosJogo.Verde);
        tabuleiro[6][8] = new Circulo(332.0, 91.0, DadosJogo.Verde);
        tabuleiro[8][5] = new Circulo(271.0, 114.0, DadosJogo.Verde);
        tabuleiro[7][6] = new Circulo(295.0, 114.0, DadosJogo.Verde);
        tabuleiro[6][7] = new Circulo(319.0, 114.0, DadosJogo.Verde);
        tabuleiro[5][8] = new Circulo(343.0, 114.0, DadosJogo.Verde);
        // area branca
        // linha de 5 (baixo)
        tabuleiro[4][0] = new Circulo(259.0, 332.0, DadosJogo.Branco);
        tabuleiro[3][1] = new Circulo(283.0, 332.0, DadosJogo.Branco);
        tabuleiro[2][2] = new Circulo(307.0, 332.0, DadosJogo.Branco);
        tabuleiro[1][3] = new Circulo(331.0, 332.0, DadosJogo.Branco);
        tabuleiro[0][4] = new Circulo(355.0, 332.0, DadosJogo.Branco);
        //linha de 6 (baixo)
        tabuleiro[5][0] = new Circulo(248.0, 308.0, DadosJogo.Branco);
        tabuleiro[4][1] = new Circulo(272.0, 308.0, DadosJogo.Branco);
        tabuleiro[3][2] = new Circulo(296.0, 308.0, DadosJogo.Branco);
        tabuleiro[2][3] = new Circulo(320.0, 308.0, DadosJogo.Branco);
        tabuleiro[1][4] = new Circulo(344.0, 308.0, DadosJogo.Branco);
        tabuleiro[0][5] = new Circulo(368.0, 309.0, DadosJogo.Branco);
        // linha de 7 (baixo)
        tabuleiro[6][0] = new Circulo(236.0, 284.0, DadosJogo.Branco);
        tabuleiro[5][1] = new Circulo(260.0, 284.0, DadosJogo.Branco);
        tabuleiro[4][2] = new Circulo(284.0, 284.0, DadosJogo.Branco);
        tabuleiro[3][3] = new Circulo(308.0, 284.0, DadosJogo.Branco);
        tabuleiro[2][4] = new Circulo(332.0, 284.0, DadosJogo.Branco);
        tabuleiro[1][5] = new Circulo(356.0, 285.0, DadosJogo.Branco);
        tabuleiro[0][6] = new Circulo(381.0, 285.0, DadosJogo.Branco);
        // linha de 8 (baixo)
        tabuleiro[7][0] = new Circulo(224.0, 261.0, DadosJogo.Branco);
        tabuleiro[6][1] = new Circulo(248.0, 261.0, DadosJogo.Branco);
        tabuleiro[5][2] = new Circulo(272.0, 261.0, DadosJogo.Branco);
        tabuleiro[4][3] = new Circulo(296.0, 261.0, DadosJogo.Branco);
        tabuleiro[3][4] = new Circulo(320.0, 261.0, DadosJogo.Branco);
        tabuleiro[2][5] = new Circulo(344.0, 262.0, DadosJogo.Branco);
        tabuleiro[1][6] = new Circulo(369.0, 262.0, DadosJogo.Branco);
        tabuleiro[0][7] = new Circulo(394.0, 263.0, DadosJogo.Branco);
        // linha de 9 (meio)
        tabuleiro[8][0] = new Circulo(213.0, 238.0, DadosJogo.Branco);
        tabuleiro[7][1] = new Circulo(237.0, 238.0, DadosJogo.Branco);
        tabuleiro[6][2] = new Circulo(261.0, 238.0, DadosJogo.Branco);
        tabuleiro[5][3] = new Circulo(285.0, 236.0, DadosJogo.Branco);
        tabuleiro[4][4] = new Circulo(309.0, 238.0, DadosJogo.Branco);
        tabuleiro[3][5] = new Circulo(333.0, 239.0, DadosJogo.Branco);
        tabuleiro[2][6] = new Circulo(358.0, 239.0, DadosJogo.Branco);
        tabuleiro[1][7] = new Circulo(383.0, 240.0, DadosJogo.Branco);
        tabuleiro[0][8] = new Circulo(407.0, 241.0, DadosJogo.Branco);
        // linha de 8 (cima)
        tabuleiro[8][1] = new Circulo(225.0, 215.0, DadosJogo.Branco);
        tabuleiro[7][2] = new Circulo(249.0, 215.0, DadosJogo.Branco);
        tabuleiro[6][3] = new Circulo(273.0, 215.0, DadosJogo.Branco);
        tabuleiro[5][4] = new Circulo(297.0, 215.0, DadosJogo.Branco);
        tabuleiro[4][5] = new Circulo(321.0, 215.0, DadosJogo.Branco);
        tabuleiro[3][6] = new Circulo(345.0, 216.0, DadosJogo.Branco);
        tabuleiro[2][7] = new Circulo(370.0, 216.0, DadosJogo.Branco);
        tabuleiro[1][8] = new Circulo(395.0, 217.0, DadosJogo.Branco);
        // linha de 7 (cima)
        tabuleiro[8][2] = new Circulo(235.0, 193.0, DadosJogo.Branco);
        tabuleiro[7][3] = new Circulo(259.0, 193.0, DadosJogo.Branco);
        tabuleiro[6][4] = new Circulo(283.0, 193.0, DadosJogo.Branco);
        tabuleiro[5][5] = new Circulo(307.0, 193.0, DadosJogo.Branco);
        tabuleiro[4][6] = new Circulo(331.0, 193.0, DadosJogo.Branco);
        tabuleiro[3][7] = new Circulo(355.0, 194.0, DadosJogo.Branco);
        tabuleiro[2][8] = new Circulo(380.0, 194.0, DadosJogo.Branco);
        // linha de 6 (cima)
        tabuleiro[8][3] = new Circulo(247.0, 167.0, DadosJogo.Branco);
        tabuleiro[7][4] = new Circulo(271.0, 167.0, DadosJogo.Branco);
        tabuleiro[6][5] = new Circulo(295.0, 167.0, DadosJogo.Branco);
        tabuleiro[5][6] = new Circulo(319.0, 167.0, DadosJogo.Branco);
        tabuleiro[4][7] = new Circulo(343.0, 167.0, DadosJogo.Branco);
        tabuleiro[3][8] = new Circulo(367.0, 168.0, DadosJogo.Branco);
        // linha de 5 (cima)                
        tabuleiro[8][4] = new Circulo(260.0, 143.0, DadosJogo.Branco);
        tabuleiro[7][5] = new Circulo(284.0, 143.0, DadosJogo.Branco);
        tabuleiro[6][6] = new Circulo(308.0, 143.0, DadosJogo.Branco);
        tabuleiro[5][7] = new Circulo(332.0, 143.0, DadosJogo.Branco);
        tabuleiro[4][8] = new Circulo(356.0, 143.0, DadosJogo.Branco);
    }

}
