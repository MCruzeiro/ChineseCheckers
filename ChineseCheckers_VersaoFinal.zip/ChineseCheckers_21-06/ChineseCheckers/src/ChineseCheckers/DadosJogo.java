package ChineseCheckers;

/**
 *<p>Dadosjogo<p>
 * A classe Dadosjogo deefine as propriedades do jogo, asssim como inicializar
 * os jogadores
 * 
 * @author João Miranda & Leonardo Andrade & Miguel Cruzeiro
 */
public class DadosJogo {

    Jogador jogador1, jogador2;
    ClientSocket cs;

    // cores

    /**
     *Cor Vermelha
     */
    public static String Vermelho = "#ff1f1f";

    /**
     *Cor Laranja
     */
    public static String Laranja = "#ffc91f";

    /**
     *Cor Amarela
     */
    public static String Amarelo = "#eeff00";

    /**
     *Cor Verde
     */
    public static String Verde = "#009427";

    /**
     *Cor Branca
     */
    public static String Branco = "#ffffff";

    /**
     *Cor Azul Claro
     */
    public static String AzulClaro = "#99ccff";

    /**
     *Cor Azul Escuro
     */
    public static String AzulEscuro = "#6666ff";


    // servidor do jogo
    final static int ServerPort = 1234;
    final static String ServerName = "localhost";

    /**
     *Construtor da classe onde se vao inicializar aos jogadores e o ClientSocket.
     * 
     */
    DadosJogo() {
        this.jogador1 = new Jogador(Vermelho, "Jogador1", true);
        this.jogador2 = new Jogador(Laranja, "Jogador2", false);
        this.cs = new ClientSocket(ServerName, ServerPort);
    }

    /**
     *Getter do jogador1
     * @return
     */
    public Jogador getJogador1() {
        return jogador1;
    }

    /**
     *Setter do jogador1
     * @param jogador1
     */
    public void setJogador1(Jogador jogador1) {
        this.jogador1 = jogador1;
    }

    /**
     *Getter do jogador2
     * @return
     */
    public Jogador getJogador2() {
        return jogador2;
    }

    /**
     *Setter do jogador2
     * @param jogador2
     */
    public void setJogador2(Jogador jogador2) {
        this.jogador2 = jogador2;
    }

    /**
     *Getter do ClientSocket
     * @return
     */
    public ClientSocket getCs() {
        return cs;
    }

    /**
     *Setter do ClientSocket
     * @param cs
     */
    public void setCs(ClientSocket cs) {
        this.cs = cs;
    }

}
