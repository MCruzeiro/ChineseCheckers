package ChineseCheckers;

import java.util.Random;

public class Jogador {

    String cor, nome;
    boolean turno;
    boolean jogadaPreparada;
    int jogadaI, jogadaJ;       //Ultimo circulo onde clicou
    int sorteio;
    boolean salto;

    public Jogador(String cor, String nome, boolean turno) {
        this.cor = cor;
        this.nome = nome;
        this.turno = turno;
        this.jogadaPreparada = false;
        this.jogadaI = 0;
        this.jogadaJ = 0;
        this.salto = false;
    }

    public int sortear() {
        //Atirar um dado ao ar para ver quem joga primeiro
        Random sortear = new Random();
        sorteio = sortear.nextInt(5) + 1;

        return sorteio;

    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isTurno() {
        return turno;
    }

    public void setTurno(boolean turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Jogador{" + "cor=" + cor + ", nome=" + nome + ", turno=" + turno + ", jogadaPreparada=" + jogadaPreparada + ", jogadaI=" + jogadaI + ", jogadaJ=" + jogadaJ + ", sorteio=" + sorteio + ", salto=" + salto + '}';
    }

    public String estado() {
        return jogadaPreparada + ":" + jogadaI + ":" + jogadaJ + ":" + salto;
    }

}
