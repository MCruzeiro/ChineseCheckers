/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

/**
 *
 * @author Asus
 */
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Circulo extends Circle {

    private String cor;
    private static final int raio = 11;

    public Circulo(double centerX, double centerY, String cor) {
        super(centerX, centerY, raio, Color.web(cor));
        this.cor = cor;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
        this.setFill(Color.web(cor));
    }

    public boolean livre() {
        return cor.equals(DadosJogo.Branco);
    }

    public boolean ocupadaJogador(Jogador j) {
        return cor.equals(j.cor);
    }

}
