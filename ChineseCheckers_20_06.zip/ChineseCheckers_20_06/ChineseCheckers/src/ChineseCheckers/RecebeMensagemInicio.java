/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import javafx.concurrent.Task;

/**
 *
 * @author Asus
 */
public class RecebeMensagemInicio extends Task {

    private ClientSocket cs;

    public RecebeMensagemInicio(ClientSocket cs) {
        this.cs = cs;
    }

    @Override
    protected String call() throws Exception {
        System.out.println("Recebe Mensagem inicial: ");
        // enquanto o socket estiver lgado e a Task não for cancelaa
        if (cs.ligado && !isCancelled()) {
            // recebe uma mensagem e notifica 
            String mensagem = cs.recebeMensagem();
            updateMessage(mensagem);
            System.out.println("Mensagem incial recebida: " + mensagem);
        }
        System.out.println("Termina receção de mensagens");

        return null;
    }

}
