/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChineseCheckers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author João Miranda
 */
public class DefinirJogadorController implements Initializable {

    @FXML
    private CheckBox CheckboxVermelho;
    @FXML
    private CheckBox CheckboxLaranja;
    @FXML
    private CheckBox CheckboxAmarelo;
    @FXML
    private CheckBox CheckboxVerde;
    @FXML
    private Button BotaoComecar;
    @FXML
    private Button BotaoRetroceder;
    @FXML
    private TextField labelNome;
    private DadosJogo dj;

    public void setDadosJogo(DadosJogo dj) {
        this.dj = dj;

        labelNome.setText(dj.jogador1.nome);

        if (dj.jogador1.cor == DadosJogo.Vermelho) {
            CheckboxVermelho.setSelected(true);
            CheckboxLaranja.setSelected(false);
            CheckboxAmarelo.setSelected(false);
            CheckboxVerde.setSelected(false);

        } else if (dj.jogador1.cor == DadosJogo.Amarelo) {
            CheckboxVermelho.setSelected(false);
            CheckboxLaranja.setSelected(false);
            CheckboxAmarelo.setSelected(true);
            CheckboxVerde.setSelected(false);

        } else if (dj.jogador1.cor == DadosJogo.Laranja) {
            CheckboxVermelho.setSelected(false);
            CheckboxLaranja.setSelected(true);
            CheckboxAmarelo.setSelected(false);
            CheckboxVerde.setSelected(false);

        } else if (dj.jogador1.cor == DadosJogo.Verde) {
            CheckboxVermelho.setSelected(false);
            CheckboxLaranja.setSelected(false);
            CheckboxAmarelo.setSelected(false);
            CheckboxVerde.setSelected(true);
        }
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void RespondeComeçar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AnimaçãoEspera.fxml"));
        Parent root = loader.load();
        AnimaçãoEsperaController ae = loader.getController();
        atualizaJogador();
        ae.setDadosJogo(dj);

        Stage window = (Stage) BotaoComecar.getScene().getWindow();
        window.setScene(new Scene(root));

    }

    @FXML
    private void RespondeRetroceder(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
        Parent root = loader.load();
        MenuController mc = loader.getController();
        atualizaJogador();
        mc.setDadosJogo(dj);

        Stage window = (Stage) BotaoRetroceder.getScene().getWindow();
        window.setScene(new Scene(root));
    }

    @FXML
    private void setNome(ActionEvent event) {
        dj.jogador1.nome = labelNome.getText();
    }

    private void atualizaJogador() {
        dj.jogador1.nome = labelNome.getText();
        if (CheckboxVermelho.isSelected()) {
            dj.jogador1.cor = DadosJogo.Vermelho;
        } else if (CheckboxAmarelo.isSelected()) {
            dj.jogador1.cor = DadosJogo.Amarelo;
        } else if (CheckboxLaranja.isSelected()) {
            dj.jogador1.cor = DadosJogo.Laranja;
        } else if (CheckboxVerde.isSelected()) {
            dj.jogador1.cor = DadosJogo.Verde;

        }
    }

    @FXML
    private void setVermelho(ActionEvent event) {
        CheckboxVermelho.setSelected(true);
        CheckboxLaranja.setSelected(false);
        CheckboxAmarelo.setSelected(false);
        CheckboxVerde.setSelected(false);

        dj.jogador1.cor = DadosJogo.Vermelho;
    }

    @FXML
    private void setLaranja(ActionEvent event) {
        CheckboxVermelho.setSelected(false);
        CheckboxLaranja.setSelected(true);
        CheckboxAmarelo.setSelected(false);
        CheckboxVerde.setSelected(false);

        dj.jogador1.cor = DadosJogo.Laranja;
    }

    @FXML
    private void setAmarelo(ActionEvent event) {
        CheckboxVermelho.setSelected(false);
        CheckboxLaranja.setSelected(false);
        CheckboxAmarelo.setSelected(true);
        CheckboxVerde.setSelected(false);

        dj.jogador1.cor = DadosJogo.Amarelo;
    }

    @FXML
    private void setVerde(ActionEvent event) {
        CheckboxVermelho.setSelected(false);
        CheckboxLaranja.setSelected(false);
        CheckboxAmarelo.setSelected(false);
        CheckboxVerde.setSelected(true);

        dj.jogador1.cor = DadosJogo.Verde;
    }

}
