package ChineseCheckers;

import java.util.Random;

/**
 *<p>Jogador<p>
 * A classe Jogador definirá as propriedades de cada Jogador 
 * 
 * @author João Miranda & Leonardo Andrade & Miguel Cruzeiro
 */
public class Jogador {

    String cor, nome;
    boolean turno; //Permite ver se é a vez do jogador jogar
    boolean jogadaPreparada;
    int jogadaI, jogadaJ;       //Ultimo circulo onde clicou
    int sorteio;
    boolean salto;

    /**
     *O construtor será inicializado com uma cor, um nome e um boolean de turno.
     * 
     * @param cor
     * @param nome
     * @param turno
     */
    public Jogador(String cor, String nome, boolean turno) {
        this.cor = cor;
        this.nome = nome;
        this.turno = turno;
        this.jogadaPreparada = false;
        this.jogadaI = 0;
        this.jogadaJ = 0;
        this.salto = false;
    }

    /**
     *O método sortear permite simular um lançamento de dados por parte do jogador,
     *de modo a decidir quem começará.
     * @return
     */
    public int sortear() {
        //Atirar um dado ao ar para ver quem joga primeiro
        Random sortear = new Random();
        sorteio = sortear.nextInt(5) + 1;

        return sorteio;

    }

    /**
     *Getter da cor
     * @return
     */
    public String getCor() {
        return cor;
    }

    /**
     *Setter da cor
     * @param cor
     */
    public void setCor(String cor) {
        this.cor = cor;
    }

    /**
     *Getter do nome
     * @return
     */
    public String getNome() {
        return nome;
    }

    /**
     *Setter do nome
     * @param nome
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     *Getter do turno
     * @return
     */
    public boolean isTurno() {
        return turno;
    }

    /**
     *Setter do turno
     * @param turno
     */
    public void setTurno(boolean turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "Jogador{" + "cor=" + cor + ", nome=" + nome + ", turno=" + turno + ", jogadaPreparada=" + jogadaPreparada + ", jogadaI=" + jogadaI + ", jogadaJ=" + jogadaJ + ", sorteio=" + sorteio + ", salto=" + salto + '}';
    }

    /**
     *Getter do estado de uma jogada, utilizado para comunicar com o servido a 
     * jogada ocorrida
     * @return
     */
    public String estado() {
        return jogadaPreparada + ":" + jogadaI + ":" + jogadaJ + ":" + salto;
    }

}
